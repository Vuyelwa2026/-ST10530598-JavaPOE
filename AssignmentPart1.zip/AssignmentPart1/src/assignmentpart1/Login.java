/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignmentpart1;

public class Login {

    // ==========================
    // Declare variables
    // ==========================

    private String firstName;
    private String surname;
    private String username;
    private String password;
    private String cellphoneNumber;

    private boolean loginSuccessful;

    // ==========================
    // Constructor
    // ==========================

    public Login(String firstName, String surname, String username,
                 String password, String cellphoneNumber) {

        this.firstName = firstName;
        this.surname = surname;
        this.username = username;
        this.password = password;
        this.cellphoneNumber = cellphoneNumber;
        this.loginSuccessful = false;
    }

    // ==========================
    // Check Username
    // ==========================

    
    //add parameters
    public boolean checkUsername(String username) {  //add parameters

        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    // ==========================
    // Check Password
    // ==========================

    public boolean checkPasswordComplexity(String password) {

        if (password == null || password.length() < 8) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;

        // Check every character in the password

        for (int i = 0; i < password.length(); i++) {

            char character = password.charAt(i);

            // Check for capital letter
            if (Character.isUpperCase(character)) {
                hasCapitalLetter = true;
            }

            // Check for number
            if (Character.isDigit(character)) {
                hasNumber = true;
            }

            // Check for special character
            if (!Character.isLetterOrDigit(character)) {
                hasSpecialChar = true;
            }
        }

        return hasCapitalLetter
                && hasNumber
                && hasSpecialChar;
    }

    // ==========================
    // Check Cellphone Number
    // ==========================

    public boolean checkCellphoneNumber( String cellphoneNumber) {

        if (cellphoneNumber == null) {
            return false;
        }

        // South African format:
        // +27 followed by 9 digits

        return cellphoneNumber.matches("\\+27[0-9]{9}");
    }

    // ==========================
    // Login User
    // ==========================

    public boolean loginUser(String enteredUsername,
                             String enteredPassword) {

        if (enteredUsername == null || enteredPassword == null) {
            loginSuccessful = false;
            return false;
        }

        if (enteredUsername.equals(username)
                && enteredPassword.equals(password)) {

            loginSuccessful = true;
            return true;

        } else {

            loginSuccessful = false;
            return false;
        }
    }

    // ==========================
    // Get Login Status
    // ==========================

    public boolean isLoginSuccessful(String LoginSucessful) {
        return loginSuccessful;
    }

    // ==========================
    // Get First Name
    // ==========================

    public String getFirstName() {
        return firstName;
    }

    // ==========================
    // Get Surname
    // ==========================

    public String getSurname() {
        return surname;
    }
}